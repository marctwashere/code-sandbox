SETUP
Open the python script and specify user params for the:
output directory
location of target folders
list of target folder names

Note: file paths cannot contain backslashes

RESULTS
Whichever targets are found will be copied to a new folder "targets". Missed targets will be listed in missed.txt. Both will be located under the OUTPUT_DIR specified in user params.