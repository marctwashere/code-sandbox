SETUP
Write a line for each "target" folder in "find_these.txt". Then, run the script at the top level directory. "python py_soln.py"

RESULTS
Whichever targets are found will be copied to a new folder "targets". Missed targets will be listed in missed.txt